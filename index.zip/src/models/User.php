<?php 

namespace Bytes\src\models;

use Bytes\system\core\Application;
use Bytes\system\database\Model;

class User extends Model {
    
}