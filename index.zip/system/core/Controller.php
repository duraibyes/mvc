<?php 
namespace Bytes\system\core;

class Controller {
    public $request;
    public $db;
    public function __construct() {
        $this->request = Application::$app->request;
        $this->db = Application::$app->db;
    }
    public function render($view, $params) {
        return Application::$app->router->render($view, $params);
    }

    public function all() {
        $statement = $this->db->pdo->prepare('SELECT * from users');
        
        $statement->execute();
        ss($statement->fetchAll());
        
    }
}