<?php

namespace Bytes\system\core;

class ErrorHandling
{
}