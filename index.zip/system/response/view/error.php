<?php 

echo  '<style>';
include 'error.css';
echo '</style>';
?>

<div id="dj-pane-stripes">
    <div class="dj-common-error-pane">
        <h1> 404 </h1>
        <div> Page Not Found </div>
    </div>
</div>
        