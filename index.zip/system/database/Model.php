<?php 
namespace Bytes\system\database;

use Bytes\src\models\User;
use Bytes\system\core\Application;
use PDO;

abstract class Model {
    public static function all() {
        $db = Application::$app->db;
        $statement = $db->pdo->query('SELECT * from users limit 3')->fetchAll();
        // $statement->setFetchMode(PDO::FETCH_CLASS, 'User');
        // $user = $statement->fetch();
        ss( $statement );
        // $statement->execute();
        // $statement->setFetchMode(PDO::FETCH_ASSOC);
        
        // $statement->setFetchMode(PDO::FETCH_ASSOC);
        // $publishers = $statement->fetchAll(PDO::FETCH_ASSOC);
        // ss( $publishers );

        // return $publishers;       
    }
}